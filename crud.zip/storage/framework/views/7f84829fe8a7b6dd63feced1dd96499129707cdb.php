<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Read</title>
</head>
<body align="center">
    <h1>Displaying Data from Database</h1>
    <form action="<?php echo e(url('search')); ?>" method="GET" >
        <input type="search" name="search" placeholder="Search Here">
        <input type="submit" value="Search">
        <br> <br>
    </form>

        <table border="2px" align="center">
            <tr>
                <td>Username</td>
                <td>Email</td>
                <td>Address</td>
                <td>Phone</td>
                <td>Image</td>
                <td>Delete</td>
                <td>Update</td>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($users->name); ?></td>
                <td><?php echo e($users->email); ?></td>
                <td><?php echo e($users->address); ?></td>
                <td><?php echo e($users->phone); ?></td>
                <td><img height="150" width="150" src="userimg/<?php echo e($users->image); ?>"> </td>
                <td>
                    <a href="<?php echo e(url('delete', $users->id)); ?>">Delete</a>
                </td>
                <td>
                    <a href="<?php echo e(url('updatedata', $users->id)); ?>">Update</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
</body>
</html>
<?php /**PATH C:\localhost\htdocs\CRUD\resources\views/read.blade.php ENDPATH**/ ?>